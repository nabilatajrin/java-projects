# Java-Programs

Here is the collection of some Java programs I have done, while learning Java to solve real projects, and some are just for practices.
